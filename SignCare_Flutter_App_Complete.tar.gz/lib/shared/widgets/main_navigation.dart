import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/router/app_router.dart';

class MainNavigation extends StatelessWidget {
  final Widget child;

  const MainNavigation({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: child,
      bottomNavigationBar: BottomNavigationBar(
        type: BottomNavigationBarType.fixed,
        currentIndex: _calculateSelectedIndex(context),
        onTap: (index) => _onItemTapped(index, context),
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: '홈',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.restaurant),
            label: '식단',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.fitness_center),
            label: '운동',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.bedtime),
            label: '수면',
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.chat),
            label: '상담',
          ),
        ],
      ),
    );
  }

  int _calculateSelectedIndex(BuildContext context) {
    final String location = GoRouterState.of(context).uri.path;
    switch (location) {
      case AppRoutes.home:
      case AppRoutes.activity:
        return 0;
      case AppRoutes.food:
        return 1;
      case AppRoutes.challenge:
        return 2;
      case AppRoutes.sleep:
        return 3;
      case AppRoutes.chat:
        return 4;
      default:
        return 0;
    }
  }

  void _onItemTapped(int index, BuildContext context) {
    switch (index) {
      case 0:
        context.go(AppRoutes.home);
        break;
      case 1:
        context.go(AppRoutes.food);
        break;
      case 2:
        context.go(AppRoutes.challenge);
        break;
      case 3:
        context.go(AppRoutes.sleep);
        break;
      case 4:
        context.go(AppRoutes.chat);
        break;
    }
  }
}

