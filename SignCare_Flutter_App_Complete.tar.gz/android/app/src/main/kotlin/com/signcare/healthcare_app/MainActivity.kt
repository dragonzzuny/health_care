package com.signcare.healthcare_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
